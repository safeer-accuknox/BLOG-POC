Java is a required.
https://www.oracle.com/java/technologies/downloads/

Extract the Java archive: tar xvf jdk-*.tar.gz

Run the init script:
chmod +x crushftp_init.sh
./crushftp_init.sh install

./Java/bin/java -jar CrushFTP.jar -a crushadmin password
or
java -jar CrushFTP.jar -a crushadmin password

Now you can login at one of these URLs:

http://servername:8080/
http://servername:9090/
https://servername:443/
