SELECT user_name as "username", count(distinct ip) as "count"
 FROM SESSIONS
 where start_time >= ? and end_time <= ?
 /*START_USERNAMES*/and user_name in (%usernames%)/*END_USERNAMES*/
 group by user_name
 order by user_name
