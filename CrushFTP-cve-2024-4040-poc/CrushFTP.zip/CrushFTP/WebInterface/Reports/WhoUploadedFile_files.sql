SELECT user_name as "username", url as "url", path as "path", file_name as "name", t.start_time as "date"
 FROM TRANSFERS t, SESSIONS s
 where t.session_rid = s.rid
 and s.start_time >= ? and s.end_time <= ?
 and t.direction = 'UPLOAD'
 and upper(path) like ?
 and upper(file_name) like ?
 /*START_USERNAMES*/and user_name in (%usernames%)/*END_USERNAMES*/
 group by user_name, url, path, file_name, t.start_time
 order by user_name, url, t.start_time
