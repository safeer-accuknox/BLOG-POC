SELECT t.rid as "rid", session_rid as "session_rid", cast(speed as bigint) as "speed", path as "path", file_name as "name", url as "url", cast(transfer_size as bigint) as "size"
 FROM TRANSFERS t, SESSIONS s
 where s.rid = t.session_rid
 and DIRECTION = ?
 and t.start_time >= ? and t.start_time <= ?
 order by t.start_time
