select s.user_name as "username", s.rid as "rid", s.start_time as "date" 
 FROM SESSIONS s
 where s.start_time >= ? and s.end_time <= ?
 /*START_USERNAMES*/and user_name in (%usernames%)/*END_USERNAMES*/
