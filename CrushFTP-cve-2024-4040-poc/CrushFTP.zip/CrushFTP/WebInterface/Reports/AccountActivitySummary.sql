select user_name as "username", ip as "ip", s.start_time as "start",s.end_time as "end", {fn TIMESTAMPDIFF(SQL_TSI_SECOND,s.start_time,s.end_time)} * 1000 as "durationRaw", sum(CASEWHEN(direction = 'UPLOAD',1,0)) as "uploadCount", sum(CASEWHEN(direction = 'DOWNLOAD',1,0)) as "downloadCount", sum(CASEWHEN(direction = 'DELETE',1,0)) as "deleteCount", sum(CASEWHEN(direction = 'RENAME',1,0)) as "renameCount", cast(sum(CASEWHEN(direction = 'UPLOAD',transfer_size,0)) as bigint) as "uploadBytes", cast(sum(CASEWHEN(direction = 'DOWNLOAD', transfer_size,0)) as bigint) as "downloadBytes"
 FROM SESSIONS s
 left join TRANSFERS t
 on s.rid = t.session_rid
 where s.start_time >= ? and s.end_time <= ?
 /*START_USERNAMES*/and user_name in (%usernames%)/*END_USERNAMES*/
 group by user_name, ip, s.start_time, s.end_time, s.rid
 order by user_name
