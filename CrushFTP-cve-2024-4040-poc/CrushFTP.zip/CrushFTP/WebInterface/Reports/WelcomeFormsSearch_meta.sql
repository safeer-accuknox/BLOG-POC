SELECT item_key as "item_key", item_value as "item_value" 
 FROM META_INFO 
 WHERE SESSION_RID = ? and TRANSFER_RID = 0 
