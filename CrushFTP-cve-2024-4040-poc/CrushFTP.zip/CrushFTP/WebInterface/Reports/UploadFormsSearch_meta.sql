SELECT item_key as "item_key", item_value as "item_value" 
 FROM META_INFO 
 WHERE TRANSFER_RID = ? 
