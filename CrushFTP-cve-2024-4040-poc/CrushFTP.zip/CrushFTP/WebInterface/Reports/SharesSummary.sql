SELECT s.user_name as "username", t.start_time as "share_time", t.session_rid as "session_rid", t.rid as "transfer_rid", path as "path", file_name as "name", url as "url", cast(transfer_size as bigint) as "size"
 FROM TRANSFERS t, SESSIONS s
 where s.rid = t.session_rid
 and DIRECTION = ?
 and t.start_time >= ? and t.start_time <= ?
 /*START_USERNAMES*/and user_name in (%usernames%)/*END_USERNAMES*/
 order by 1 desc
