select user_name as "username", sum(CASEWHEN(direction = 'UPLOAD',1,0)) as "uploadCount", sum(CASEWHEN(direction = 'DOWNLOAD',1,0)) as "downloadCount", cast(sum(CASEWHEN(direction = 'UPLOAD',transfer_size,0)) as bigint) as "uploadBytes", cast(sum(CASEWHEN(direction = 'DOWNLOAD', transfer_size,0)) as bigint) as "downloadBytes"
 FROM TRANSFERS t, SESSIONS s
 where s.rid = t.session_rid
 and s.start_time >= ? and s.end_time <= ?
 /*START_USERNAMES*/and user_name in (%usernames%)/*END_USERNAMES*/
 group by user_name
 order by user_name
