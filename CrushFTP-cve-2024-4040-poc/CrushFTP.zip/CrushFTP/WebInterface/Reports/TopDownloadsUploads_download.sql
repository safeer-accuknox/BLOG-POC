SELECT count(t.rid) as "count", cast(avg(speed) as bigint) as "averageSpeed", path as "path", file_name as "name", url as "url", cast(transfer_size as bigint) as "size"
 FROM TRANSFERS t, SESSIONS s
 where s.rid = t.session_rid
 and DIRECTION = ?
 and t.start_time >= ? and t.start_time <= ?
 /*START_USERNAMES*/and user_name in (%usernames%)/*END_USERNAMES*/
 group by path,file_name,url,transfer_size
 order by 1 desc
 limit ?
