SELECT user_name as "username", s.ip as "ip", t.start_time as "date", path as "path", file_name as "name", url as "url", cast(transfer_size as bigint) as "size", cast(speed as bigint)*1024 as "speed"
 FROM TRANSFERS t, SESSIONS s
 where s.rid = t.session_rid
 and DIRECTION = ?
 and t.start_time >= ? and t.start_time <= ?
 order by t.start_time
