SELECT user_name as "username", start_time as "start_time", ip as "ip"
 FROM SESSIONS
 where success_login = 'false' and start_time >= ? and end_time <= ?
 /*START_USERNAMES*/and user_name in (%usernames%)/*END_USERNAMES*/
group by user_name, start_time, ip
 order by user_name
