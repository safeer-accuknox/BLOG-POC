SELECT DIRECTION as "direction", cast(speed as bigint) as "speed", path as "path", file_name as "name", url as "url", cast(transfer_size as bigint) as "size"
 FROM TRANSFERS t
 where t.SESSION_RID = ? 
