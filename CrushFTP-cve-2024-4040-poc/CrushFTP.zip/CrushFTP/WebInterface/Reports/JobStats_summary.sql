select session, ip, user_name as "username", direction, path, speed, transfer_size, file_name
 FROM SESSIONS s
 left join TRANSFERS t
 on s.rid = t.session_rid
 where s.start_time >= ? and s.end_time <= ?
 and server_group = 'Job'
 order by session
