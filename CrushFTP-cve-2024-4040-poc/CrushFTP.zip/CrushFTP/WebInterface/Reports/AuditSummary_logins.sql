SELECT user_name as "username", ip as "ip", start_time as "date", success_login as "success_login"
 FROM SESSIONS s
 where user_name = ? and start_time >= ? and start_time <= ? and success_login = ?
 order by start_time
