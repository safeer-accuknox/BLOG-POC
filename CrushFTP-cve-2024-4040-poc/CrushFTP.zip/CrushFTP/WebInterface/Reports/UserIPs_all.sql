SELECT user_name as "username", ip as "ip", count(ip) as "count"
 FROM SESSIONS
 where start_time >= ? and end_time <= ?
 /*START_USERNAMES*/and user_name in (%usernames%)/*END_USERNAMES*/
 group by user_name, ip
 order by user_name
