SELECT session_rid as "session_rid", transfer_rid as "transfer_rid", item_key as "item_key", item_value as "item_value"
 FROM META_INFO where session_rid in (%session_rids%)
 order by SESSION_RID, TRANSFER_RID, RID