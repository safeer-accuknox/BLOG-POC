select s.rid as "rid" 
 FROM TRANSFERS t, SESSIONS s
 where s.rid = t.session_rid
 and s.start_time >= ? and s.end_time <= ?
 /*START_USERNAMES*/and user_name in (%usernames%)/*END_USERNAMES*/
