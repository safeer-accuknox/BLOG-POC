
Hey! Thanks for submitting a pull request! 


Are you adding a new map? Additionnal maps shall be added to the mapael-maps repository (https://github.com/neveldo/mapael-maps)


Before submitting, please check the existing Pull Requests (https://github.com/neveldo/jQuery-Mapael/pulls).

For new feature, please provide a working example (e.g. using JSFiddle https://jsfiddle.net/)

For more information, see the `CONTRIBUTING` guide.

